typedef struct {
    PyObject_HEAD
    PyObject* gi_code;
} PyGenObject;
